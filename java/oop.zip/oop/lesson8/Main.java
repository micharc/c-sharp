package oop.lesson8;

/**
 * Чарков Михаил, номер группы мне неизвестен :)
 */

public class Main {

    public static void main(String[] args) {

//        Student s1 = new Student((long)1, "Иван", "Иванов", "Иванович");
//        Student s2 = new Student((long)2, "Петр", "Петров", "Петрович");
//        Student s3 = new Student((long)3, "Кирилл", "Кириллов", "Кириллович");
//
//        StudentGroup sg1 = new StudentGroup();
//        List<Student> studentList = new ArrayList<>();
//        studentList.add(s1);
//        studentList.add(s2);
//        studentList.add(s3);
//        sg1.setStudentList(studentList);
//
//        StudentGroupService sgs1 = new StudentGroupService();
//        System.out.printf(sgs1.getSortedStudentList().toString());
//        System.out.printf(sgs1.getSortedStudentByFIO().toString());

    }

}
